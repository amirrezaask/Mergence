declare module "*.css" {
  const content: string
  export default content
}

declare module "*.png" {
  const src: string
  export default src
}

declare module "@xterm/xterm/css/xterm.css" {}
