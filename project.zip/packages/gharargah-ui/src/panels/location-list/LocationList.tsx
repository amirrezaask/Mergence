import type { ListItem } from "@gharargah/workspace"
import { ListRow } from "@/components/ListRow.js"
import { gharargahScrollFadeClass } from "@/motion/tokens.js"
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyTitle,
} from "@/components/ui/empty.js"
import { Lister, type ListerNode } from "@/lister/index.js"
import { cn } from "@/lib/utils.js"
import { useMemo } from "react"

export type LocationListProps = {
  listId: string
  items: ListItem[]
  onOpenItem: (item: ListItem) => void
  loading?: boolean
  emptyTitle?: string
  emptyDescription?: string
  header?: React.ReactNode
  feed?: string
  /** Show Lister local-filter input (default off; search tab enables). */
  showInput?: boolean
  filterPlaceholder?: string
}

export function LocationList({
  listId,
  items,
  onOpenItem,
  loading = false,
  emptyTitle = "No results",
  emptyDescription = "Nothing to show in this list.",
  header,
  feed,
  showInput = false,
  filterPlaceholder = "Filter…",
}: LocationListProps) {
  const listerItems = useMemo<ListerNode<ListItem>[]>(
    () =>
      items.map(item => ({
        id: item.id,
        searchText: `${item.label} ${item.path} ${item.detail ?? ""} ${item.line}:${item.column}`,
        data: item,
      })),
    [items],
  )

  return (
    <div
      className="flex h-full min-h-0 flex-1 flex-col bg-background text-foreground"
      data-gharargah-list-panel={listId}
      data-gharargah-location-list
      data-gharargah-list-feed={feed}
    >
      {header}
      <Lister
        listId={listId}
        mode="flat"
        flatVariant="plain"
        filter="local"
        showInput={showInput}
        autoFocusInput={false}
        placeholder={filterPlaceholder}
        items={listerItems}
        listClassName={cn(
          "m-0 min-h-0 flex-1 list-none overflow-auto bg-background p-1",
          gharargahScrollFadeClass,
        )}
        className="min-h-0 flex-1"
        emptyState={
          loading ? null : (
            <div className="p-1">
              <Empty className="border-0 py-4">
                <EmptyHeader>
                  <EmptyTitle className="text-sm">{emptyTitle}</EmptyTitle>
                  <EmptyDescription className="text-xs">{emptyDescription}</EmptyDescription>
                </EmptyHeader>
              </Empty>
            </div>
          )
        }
        onActivate={node => onOpenItem(node.data)}
        render={(node, ctx) => (
          <ListRow
            data-gharargah-list-item
            isActive={ctx.selected}
            className="h-full w-full min-w-0 px-2 py-0.5"
            onClick={() => onOpenItem(node.data)}
          >
            <span
              data-slot="row-label"
              className="truncate text-sm font-medium text-foreground group-hover:text-accent-foreground"
            >
              {node.data.label}
            </span>
            <span
              data-slot="row-detail"
              className="truncate font-mono text-xs tabular-nums text-foreground"
            >
              {node.data.path}:{node.data.line}:{node.data.column}
              {node.data.detail ? ` · ${node.data.detail}` : ""}
            </span>
          </ListRow>
        )}
      />
    </div>
  )
}
